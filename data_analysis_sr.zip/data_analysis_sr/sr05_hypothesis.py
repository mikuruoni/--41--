"""SR 5. Testing a statistical hypothesis on the own dataset.

Main question: do critics rate M-rated (Mature 17+) games differently
from E-rated (Everyone) games?  Two-sample t-test (Welch).
Extra: one-sample t-test - is the mean critic score equal to 75
(Metacritic's lower bound of 'generally favorable reviews')?
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

from common import load_clean, save_fig, header

ALPHA = 0.05
df = load_clean()
m = df.loc[df["Rating"] == "M", "Critic_Score"].to_numpy()
e = df.loc[df["Rating"] == "E", "Critic_Score"].to_numpy()

header("1. Hypotheses")
print("mu_M = mean critic score of M-rated games, mu_E = of E-rated games")
print("H0: mu_M = mu_E   (rating does not change the mean critic score)")
print("H1: mu_M != mu_E  (two-sided)")
print(f"alpha = {ALPHA}")

header("2. Samples")
for name, x in [("M", m), ("E", e)]:
    print(f"{name}: n = {len(x):5d}, mean = {x.mean():.3f}, sd = {x.std(ddof=1):.3f}, "
          f"median = {np.median(x):.1f}, skew = {stats.skew(x):.3f}")

header("3. Assumptions")
rng = np.random.default_rng(42)
for name, x in [("M", m), ("E", e)]:
    sub = rng.choice(x, 500, replace=False)
    w, p_sh = stats.shapiro(sub)
    print(f"Shapiro-Wilk ({name}, random 500): W = {w:.4f}, p = {p_sh:.2e}")
print("-> strict normality is rejected (big samples make the test very sensitive),\n"
      "   but |skew| < 1 and n > 1000 in both groups, so by the CLT the sample\n"
      "   means are ~normal and the t-test is valid.")
lev, p_lev = stats.levene(m, e)
print(f"Levene: W = {lev:.3f}, p = {p_lev:.2e} -> borderline; Welch t-test (equal_var=False) is safe either way")

header("4. Two-sample Welch t-test")
t, p = stats.ttest_ind(m, e, equal_var=False)
diff = m.mean() - e.mean()
se = np.sqrt(m.var(ddof=1) / len(m) + e.var(ddof=1) / len(e))
dof = se ** 4 / ((m.var(ddof=1) / len(m)) ** 2 / (len(m) - 1) + (e.var(ddof=1) / len(e)) ** 2 / (len(e) - 1))
tcrit = stats.t.ppf(1 - ALPHA / 2, dof)
ci = (diff - tcrit * se, diff + tcrit * se)
pooled_sd = np.sqrt(((len(m) - 1) * m.var(ddof=1) + (len(e) - 1) * e.var(ddof=1)) / (len(m) + len(e) - 2))
d = diff / pooled_sd
print(f"t = {t:.4f}, df = {dof:.1f}, p-value = {p:.3e}")
print(f"critical |t| for alpha={ALPHA}: {tcrit:.3f}")
print(f"difference of means = {diff:.3f} points, 95% CI = ({ci[0]:.3f}; {ci[1]:.3f})")
print(f"effect size Cohen's d = {d:.3f}")
print("decision:", "reject H0" if p < ALPHA else "fail to reject H0")

u, p_u = stats.mannwhitneyu(m, e, alternative="two-sided")
print(f"robustness check, Mann-Whitney U: U = {u:.0f}, p = {p_u:.3e}")

header("5. Extra: one-sample t-test, H0: mu = 75")
x = df["Critic_Score"].to_numpy()
t1, p1 = stats.ttest_1samp(x, 75)
print(f"n = {len(x)}, mean = {x.mean():.3f}, t = {t1:.3f}, p = {p1:.3e}")
print("decision:", "reject H0" if p1 < ALPHA else "fail to reject H0",
      "-> the average game in the dataset is below 'generally favorable' (75)")

fig, axes = plt.subplots(1, 2, figsize=(12, 4))
bins = np.arange(10, 101, 4)
axes[0].hist(e, bins=bins, alpha=0.6, density=True, label=f"E (n={len(e)})", color="#4C72B0")
axes[0].hist(m, bins=bins, alpha=0.6, density=True, label=f"M (n={len(m)})", color="#C44E52")
axes[0].axvline(e.mean(), color="#4C72B0", ls="--")
axes[0].axvline(m.mean(), color="#C44E52", ls="--")
axes[0].set_xlabel("Critic score (0-100)")
axes[0].set_ylabel("Density")
axes[0].set_title("Critic score: E vs M rated games")
axes[0].legend()
means = [e.mean(), m.mean()]
errs = [tcrit * e.std(ddof=1) / np.sqrt(len(e)), tcrit * m.std(ddof=1) / np.sqrt(len(m))]
axes[1].errorbar(["E", "M"], means, yerr=errs, fmt="o", capsize=8, color="black")
axes[1].set_ylabel("Mean critic score, 95% CI")
axes[1].set_title(f"Welch t = {t:.2f}, p = {p:.1e}")
save_fig(fig, "sr05_ttest")
