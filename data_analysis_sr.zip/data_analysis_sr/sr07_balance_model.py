"""SR 7. Balance (calculation) deterministic model.

Process: economics of a small indie game sold on a digital store (Steam-like).
Balance:  Profit = Net revenue - Development cost - Marketing - Fixed post-launch costs
  Gross revenue  R  = P * Q
  Store fee         = c * R                (platform commission)
  Refunds           = r * R
  Taxes on income   = t * (R - fee - refunds)       (simplified single tax)
  Net revenue    NR = (1 - c - r) * R * (1 - t)
  Development    D  = team * months * salary + tools
  Profit         Pi = NR - D - M - S
Break-even units: Q* = (D + M + S) / (P * (1 - c - r) * (1 - t))
"""
from dataclasses import dataclass, asdict

import numpy as np
import matplotlib.pyplot as plt

from common import save_fig, header


@dataclass
class GameProject:
    price: float = 15.0          # P, USD per copy
    units: int = 30_000          # Q, copies sold in the first 2 years
    store_fee: float = 0.30      # c, share of gross revenue
    refund_rate: float = 0.05    # r, share of gross revenue refunded
    tax_rate: float = 0.05       # t, simplified tax on net income (single-tax case)
    team: int = 4                # people
    months: int = 18             # development time
    salary: float = 2_000.0      # USD per person per month
    tools: float = 6_000.0       # engines, assets, software licences, USD
    marketing: float = 25_000.0  # M, USD
    support: float = 10_000.0    # S, post-launch support/patches, USD


def evaluate(g: GameProject) -> dict:
    gross = g.price * g.units
    fee = g.store_fee * gross
    refunds = g.refund_rate * gross
    taxable = gross - fee - refunds
    tax = g.tax_rate * taxable
    net = taxable - tax
    dev = g.team * g.months * g.salary + g.tools
    costs = dev + g.marketing + g.support
    profit = net - costs
    unit_net = g.price * (1 - g.store_fee - g.refund_rate) * (1 - g.tax_rate)
    return {
        "gross_revenue": gross, "store_fee": fee, "refunds": refunds, "tax": tax,
        "net_revenue": net, "development": dev, "marketing": g.marketing,
        "support": g.support, "total_costs": costs, "profit": profit,
        "roi_%": profit / costs * 100, "net_per_copy": unit_net,
        "break_even_units": costs / unit_net,
    }


if __name__ == "__main__":
    base = GameProject()
    header("1. Inputs")
    for k, v in asdict(base).items():
        print(f"  {k:<12} = {v}")

    header("2. Balance calculation (base case)")
    res = evaluate(base)
    for k, v in res.items():
        print(f"  {k:<16} = {v:>14,.2f}")

    # balance self-check: everything the players paid is split exactly into parts
    parts = res["store_fee"] + res["refunds"] + res["tax"] + res["net_revenue"]
    assert abs(parts - res["gross_revenue"]) < 1e-6
    assert abs(res["net_revenue"] - res["total_costs"] - res["profit"]) < 1e-6
    print("\nbalance check passed: gross = fee + refunds + tax + net;  net = costs + profit")

    header("3. Scenarios")
    for name, kw in [("pessimistic", dict(units=12_000, price=12.0)),
                     ("base", {}),
                     ("optimistic", dict(units=80_000, price=18.0)),
                     ("longer dev (+6 months)", dict(months=24))]:
        r = evaluate(GameProject(**kw))
        print(f"  {name:<24} profit = {r['profit']:>12,.0f}  ROI = {r['roi_%']:>7.1f}%  "
              f"break-even = {r['break_even_units']:>8,.0f} copies")

    # break-even chart
    q = np.linspace(0, 60_000, 200)
    net_line = q * res["net_per_copy"]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(q, net_line / 1000, label="Net revenue")
    ax.axhline(res["total_costs"] / 1000, color="#C44E52", label="Total costs")
    ax.axvline(res["break_even_units"], color="gray", ls="--",
               label=f"Break-even = {res['break_even_units']:,.0f} copies")
    ax.scatter([base.units], [res["net_revenue"] / 1000], color="black", zorder=3,
               label=f"Base case: {base.units:,} copies")
    ax.set_xlabel("Copies sold")
    ax.set_ylabel("Thousand USD")
    ax.set_ylim(0, None)
    ax.set_title("Indie game: break-even analysis")
    ax.legend()
    save_fig(fig, "sr07_break_even")
