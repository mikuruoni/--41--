"""SR 8. Transportation problem and assignment problem (linear programming).

Transport: a distributor ships boxed game consoles from 3 warehouses
to 4 game stores.  Assignment: 4 QA testers, 4 games to test.
"""
import numpy as np
import pandas as pd
from scipy.optimize import linprog, linear_sum_assignment

from common import header

# ------------------------------------------------------------------ transport
header("1. Transportation problem")
warehouses = ["Warsaw", "Lublin", "Lviv"]
stores = ["Lutsk", "Rivne", "Ternopil", "Kovel"]
supply = np.array([120, 80, 100])                 # consoles available
demand = np.array([90, 70, 60, 80])               # consoles ordered
cost = np.array([                                 # USD per console
    [9.0, 11.0, 12.0, 8.0],
    [6.0, 8.0, 9.0, 5.0],
    [4.0, 5.0, 3.0, 6.0],
])
print("cost matrix, USD per console:")
print(pd.DataFrame(cost, index=warehouses, columns=stores).to_string())
print(f"supply = {supply.tolist()} (total {supply.sum()}), "
      f"demand = {demand.tolist()} (total {demand.sum()}) -> balanced (closed) problem")

m, n = cost.shape
c = cost.ravel()                                  # x[i, j] -> x[i * n + j]
A_eq, b_eq = [], []
for i in range(m):                                # each warehouse ships all its stock
    row = np.zeros(m * n); row[i * n:(i + 1) * n] = 1
    A_eq.append(row); b_eq.append(supply[i])
for j in range(n):                                # each store gets exactly its order
    row = np.zeros(m * n); row[j::n] = 1
    A_eq.append(row); b_eq.append(demand[j])
res = linprog(c, A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=(0, None), method="highs")
plan = res.x.reshape(m, n).round(6)
print(f"\nsolver status: {res.message}")
print("optimal plan, consoles:")
print(pd.DataFrame(plan, index=warehouses, columns=stores).astype(int).to_string())
print(f"minimal total cost = {res.fun:,.2f} USD")
print(f"number of used routes = {(plan > 0).sum()} (basic solution has at most m+n-1 = {m + n - 1})")

# compare with a naive 'north-west corner' plan
s, d = supply.copy(), demand.copy()
nw = np.zeros_like(cost)
i = j = 0
while i < m and j < n:
    q = min(s[i], d[j]); nw[i, j] = q; s[i] -= q; d[j] -= q
    if s[i] == 0: i += 1
    else: j += 1
print(f"north-west corner plan cost = {(nw * cost).sum():,.2f} USD "
      f"-> LP saves {(nw * cost).sum() - res.fun:,.2f} USD")

# ------------------------------------------------------------------ assignment
header("2. Assignment problem")
testers = ["Anna", "Bohdan", "Iryna", "Oleh"]
games = ["Shooter", "RPG", "Racing", "Puzzle"]
hours = np.array([                                # hours to fully test a build
    [14, 22, 16, 9],
    [11, 25, 13, 12],
    [18, 15, 17, 10],
    [12, 20, 10, 14],
])
print("testing time, hours:")
print(pd.DataFrame(hours, index=testers, columns=games).to_string())

k = len(testers)
A_eq, b_eq = [], []
for i in range(k):                                # each tester gets exactly one game
    row = np.zeros(k * k); row[i * k:(i + 1) * k] = 1
    A_eq.append(row); b_eq.append(1)
for j in range(k):                                # each game gets exactly one tester
    row = np.zeros(k * k); row[j::k] = 1
    A_eq.append(row); b_eq.append(1)
res2 = linprog(hours.ravel(), A_eq=np.array(A_eq), b_eq=np.array(b_eq),
               bounds=(0, 1), method="highs")
x = res2.x.reshape(k, k).round(6)
print("\nLP solution matrix x[i, j] (1 = tester i tests game j):")
print(pd.DataFrame(x.astype(int), index=testers, columns=games).to_string())
for i, j in zip(*np.nonzero(x)):
    print(f"  {testers[i]:<7} -> {games[j]:<8} {hours[i, j]} h")
print(f"minimal total time = {res2.fun:.0f} h")

rows, cols = linear_sum_assignment(hours)        # Hungarian algorithm, check
print(f"Hungarian algorithm (scipy linear_sum_assignment): total = {hours[rows, cols].sum()} h "
      f"-> {'same' if hours[rows, cols].sum() == round(res2.fun) else 'DIFFERENT'} optimum")
print("LP relaxation gives an integer 0/1 answer by itself: the constraint matrix is\n"
      "totally unimodular, so every vertex of the polytope is integer.")
