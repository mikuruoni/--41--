# Самостійні роботи 1–11 — Башлаєв Володимир, ІТ-41

Набір даних: Video Game Sales with Ratings (Kaggle, rush4ratio)
https://www.kaggle.com/datasets/rush4ratio/video-game-sales-with-ratings
Файл `data/Video_Games_Sales_as_at_22_Dec_2016.csv` уже лежить у папці `data/`.

## Коди активацій (Windows, PowerShell)

```powershell
cd data_analysis_sr
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Якщо PowerShell блокує Activate.ps1:
```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```
cmd.exe: `.venv\Scripts\activate.bat`  ·  Linux/macOS: `source .venv/bin/activate`

## Запуск (строго по порядку — sr02 створює чисту таблицю для решти)

```powershell
python sr01_python_basics.py
python sr02_dataset.py
python sr03_descriptive.py
python sr04_distributions.py
python sr05_hypothesis.py
python sr06_regression.py
python sr07_balance_model.py
python sr08_transport_assignment.py
python sr09_monte_carlo.py
python sr10_ml.py
```

Усе разом із збереженням виводу у файли:
```powershell
foreach ($n in "01_python_basics","02_dataset","03_descriptive","04_distributions","05_hypothesis","06_regression","07_balance_model","08_transport_assignment","09_monte_carlo","10_ml") { python "sr$n.py" | Out-File -Encoding utf8 "output\sr$($n.Substring(0,2)).txt" }
```

Графіки зберігаються в `figures/`, консольний вивід — в `output/`.
Деактивація середовища: `deactivate`.
