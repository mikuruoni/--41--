"""Shared helpers for all independent works (SR 2-11).

Dataset: Video Game Sales with Ratings (Kaggle, rush4ratio),
file data/Video_Games_Sales_as_at_22_Dec_2016.csv
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")          # save figures to files, no GUI window needed
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
RAW_CSV = BASE / "data" / "Video_Games_Sales_as_at_22_Dec_2016.csv"
CLEAN_CSV = BASE / "data" / "games_clean.csv"
LONG_CSV = BASE / "data" / "region_sales_long.csv"
FIG_DIR = BASE / "figures"
FIG_DIR.mkdir(exist_ok=True)

SEED = 42

plt.rcParams.update({
    "figure.figsize": (8, 4.8),
    "figure.dpi": 110,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "font.size": 10,
})


def load_clean() -> pd.DataFrame:
    """Load the tidy table produced by sr02_dataset.py."""
    if not CLEAN_CSV.exists():
        raise SystemExit("games_clean.csv not found - run sr02_dataset.py first")
    df = pd.read_csv(CLEAN_CSV)
    for col in ["Platform", "Genre", "Rating", "Platform_Family", "Publisher"]:
        df[col] = df[col].astype("category")
    return df


def save_fig(fig, name: str) -> None:
    path = FIG_DIR / f"{name}.png"
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"[figure saved] figures/{name}.png")


def header(title: str) -> None:
    line = "=" * 70
    print(f"\n{line}\n{title}\n{line}")
