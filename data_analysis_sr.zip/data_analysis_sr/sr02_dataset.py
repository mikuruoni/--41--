"""SR 2. Own dataset for the course: load, clean, tidy, describe.

Source: Kaggle "Video Game Sales with Ratings" (Rush Kirubi),
https://www.kaggle.com/datasets/rush4ratio/video-game-sales-with-ratings
Sales data from VGChartz, scores from Metacritic, state as of 22 Dec 2016.
"""
import pandas as pd

from common import RAW_CSV, CLEAN_CSV, LONG_CSV, header

FAMILY = {
    "PS": "Sony", "PS2": "Sony", "PS3": "Sony", "PS4": "Sony", "PSP": "Sony", "PSV": "Sony",
    "XB": "Microsoft", "X360": "Microsoft", "XOne": "Microsoft",
    "Wii": "Nintendo", "WiiU": "Nintendo", "DS": "Nintendo", "3DS": "Nintendo",
    "GC": "Nintendo", "GBA": "Nintendo", "N64": "Nintendo",
    "PC": "PC", "DC": "Sega",
}

header("1. Raw file")
raw = pd.read_csv(RAW_CSV)
print("shape:", raw.shape)
print(raw.head(3).to_string())
print("\nmissing values per column:")
print(raw.isna().sum().to_string())
print("\nUser_Score == 'tbd':", (raw["User_Score"] == "tbd").sum())

header("2. Cleaning")
df = raw.copy()
steps = []

df["User_Score"] = pd.to_numeric(df["User_Score"].replace("tbd", pd.NA), errors="coerce")
steps.append(("'tbd' in User_Score -> NaN, column to float", len(df)))

need = ["Name", "Year_of_Release", "Genre", "Critic_Score", "User_Score",
        "Critic_Count", "User_Count", "Rating"]
df = df.dropna(subset=need)
steps.append(("drop rows without scores / year / rating", len(df)))

df = df[df["Rating"].isin(["E", "E10+", "T", "M"])]
steps.append(("keep ESRB ratings E, E10+, T, M (drop AO/K-A/RP, 1 game each)", len(df)))

key = ["Name", "Platform", "Year_of_Release"]
dups = df[df.duplicated(key, keep=False)]
print("duplicated (Name, Platform, Year):")
print(dups[key + ["Global_Sales"]].to_string())
sales_cols = ["NA_Sales", "EU_Sales", "JP_Sales", "Other_Sales", "Global_Sales"]
agg = {c: "sum" for c in sales_cols}
agg.update({c: "first" for c in df.columns if c not in sales_cols + key})
df = df.groupby(key, as_index=False, sort=False).agg(agg)
steps.append(("merge duplicates (sales summed)", len(df)))

df["Year_of_Release"] = df["Year_of_Release"].astype(int)
df["Critic_Count"] = df["Critic_Count"].astype(int)
df["User_Count"] = df["User_Count"].astype(int)
df["Platform_Family"] = df["Platform"].map(FAMILY).fillna("Other")
df["Publisher"] = df["Publisher"].fillna("Unknown")
df = df[["Name", "Platform", "Platform_Family", "Year_of_Release", "Genre", "Publisher",
         "Developer", "Rating", "NA_Sales", "EU_Sales", "JP_Sales", "Other_Sales",
         "Global_Sales", "Critic_Score", "Critic_Count", "User_Score", "User_Count"]]

for text, n in steps:
    print(f"  {text:<62} rows left: {n}")

check = (df[["NA_Sales", "EU_Sales", "JP_Sales", "Other_Sales"]].sum(axis=1)
         - df["Global_Sales"]).abs()
print(f"\nGlobal_Sales vs sum of regions: max |diff| = {check.max():.2f} mln (rounding in source)")

header("3. Tidy form")
print("Wide table: one row = one game on one platform. The four regional sales\n"
      "columns hide one variable 'Region' in column names -> melt to long form.")
long = df.melt(id_vars=["Name", "Platform", "Year_of_Release", "Genre"],
               value_vars=["NA_Sales", "EU_Sales", "JP_Sales", "Other_Sales"],
               var_name="Region", value_name="Sales_mln")
# NOTE: plain "NA" would be read back by pandas as a missing value -> use full names
long["Region"] = long["Region"].map({"NA_Sales": "NorthAmerica", "EU_Sales": "Europe",
                                     "JP_Sales": "Japan", "Other_Sales": "Other"})
print("long table shape:", long.shape)
print(long.head(8).to_string())

df.to_csv(CLEAN_CSV, index=False)
long.to_csv(LONG_CSV, index=False)
print(f"\nsaved: {CLEAN_CSV.name} ({df.shape[0]} x {df.shape[1]}), "
      f"{LONG_CSV.name} ({long.shape[0]} x {long.shape[1]})")

header("4. Dataset passport")
print("rows:", len(df), "| columns:", df.shape[1])
print("years:", df["Year_of_Release"].min(), "-", df["Year_of_Release"].max())
print("platforms:", df["Platform"].nunique(), "| genres:", df["Genre"].nunique(),
      "| publishers:", df["Publisher"].nunique())
print("\ndtypes:")
print(df.dtypes.to_string())
