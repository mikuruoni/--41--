"""SR 4. Discrete distributions (binomial and Poisson) on the own dataset."""
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

from common import load_clean, save_fig, header

df = load_clean()

# ------------------------------------------------------------------ binomial
header("Task 1. Binomial: how many of n random games are 'critics hits' (score >= 80)?")
p = (df["Critic_Score"] >= 80).mean()
n, k = 10, 3
print(f"p = P(Critic_Score >= 80) estimated from {len(df)} games = {p:.4f}")
print(f"n = {n} games picked at random, X = number of hits among them")

pk = stats.binom.pmf(k, n, p)
p_at_least_1 = 1 - stats.binom.pmf(0, n, p)
p_le_2 = stats.binom.cdf(2, n, p)
ex, var = n * p, n * p * (1 - p)
print(f"P(X = {k})        = C({n},{k}) p^{k} (1-p)^{n - k} = {pk:.4f}")
print(f"P(X >= 1)       = 1 - (1-p)^{n} = {p_at_least_1:.4f}")
print(f"P(X <= 2)       = {p_le_2:.4f}")
print(f"E(X) = n*p       = {ex:.4f}   (scipy: {stats.binom.mean(n, p):.4f})")
print(f"Var(X) = n*p*q   = {var:.4f}   (scipy: {stats.binom.var(n, p):.4f})")
print(f"sigma(X)         = {np.sqrt(var):.4f}")

# empirical check: draw 20 000 random samples of 10 games from the dataset
rng = np.random.default_rng(42)
hits = (df["Critic_Score"] >= 80).to_numpy()
sims = np.array([hits[rng.choice(len(hits), n, replace=False)].sum() for _ in range(20_000)])
print(f"simulation from the real data: P(X={k}) ~ {(sims == k).mean():.4f}, "
      f"mean ~ {sims.mean():.4f}, var ~ {sims.var():.4f}")

# ------------------------------------------------------------------ Poisson
header("Task 2. Poisson: number of blockbusters (>= 5 mln copies) released per year")
all_years = range(2001, 2017)
counts_all = (df[df["Global_Sales"] >= 5]
              .groupby("Year_of_Release").size()
              .reindex(all_years, fill_value=0))
print("blockbusters per year:", {y: int(c) for y, c in counts_all.items()})
print(f"2001-2016: mean = {counts_all.mean():.3f}, variance = {counts_all.var():.3f} "
      "-> variance >> mean (overdispersion): intensity is NOT constant over the whole period")
print("share of blockbusters among all games:",
      f"{(df['Global_Sales'] >= 5).mean() * 100:.2f}% -> rare event")

# stable period: one console generation (PS3 / X360 / Wii), intensity ~ constant
counts = counts_all.loc[2005:2012]
lam = counts.mean()
print(f"\nstable period 2005-2012: counts = {list(map(int, counts))}")
print(f"lambda = mean = {lam:.3f}, sample variance = {counts.var():.3f} "
      "-> variance ~ mean, Poisson is acceptable")

for kk in [8, 11, 15]:
    print(f"P(X = {kk:2d}) = {stats.poisson.pmf(kk, lam):.4f}")
print(f"P(X <= 6)  = {stats.poisson.cdf(6, lam):.4f}  (a 'weak' year)")
print(f"P(X >= 15) = {stats.poisson.sf(14, lam):.4f}  (a 'record' year)")
print(f"E(X) = Var(X) = lambda = {lam:.3f}, sigma = {np.sqrt(lam):.3f}")

# figures
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
x = np.arange(0, n + 1)
axes[0].bar(x - 0.2, stats.binom.pmf(x, n, p), width=0.4, label="Binomial model", color="#4C72B0")
axes[0].bar(x + 0.2, np.bincount(sims, minlength=n + 1) / len(sims), width=0.4,
            label="Sampling from data", color="#DD8452")
axes[0].set_xlabel("Number of critics hits among 10 games")
axes[0].set_ylabel("Probability")
axes[0].set_title(f"Binomial(n={n}, p={p:.3f})")
axes[0].legend()

xp = np.arange(0, 25)
axes[1].bar(xp, stats.poisson.pmf(xp, lam), color="#55A868", label=f"Poisson(lambda={lam:.2f})")
vals, freq = np.unique(counts, return_counts=True)
axes[1].scatter(vals, freq / len(counts), color="#C44E52", zorder=3, label="Observed 2005-2012 (share)")
axes[1].set_xlabel("Blockbusters released in a year")
axes[1].set_ylabel("Probability")
axes[1].set_title("Poisson model of blockbusters per year")
axes[1].legend()
save_fig(fig, "sr04_binom_poisson")
