"""SR 6. Correlation analysis and regression model of the own dataset.

Question: how strongly is commercial success (sales) linked with critics'
opinion, and what else explains sales?  Sales are log10-transformed
because their distribution is extremely right-skewed (SR 3).
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

from common import load_clean, save_fig, header

df = load_clean()
df["log_sales"] = np.log10(df["Global_Sales"])
df["log_critic_count"] = np.log10(df["Critic_Count"])

header("1. Correlation: Critic_Score vs sales")
r_raw, p_raw = stats.pearsonr(df["Critic_Score"], df["Global_Sales"])
r_log, p_log = stats.pearsonr(df["Critic_Score"], df["log_sales"])
rho, p_rho = stats.spearmanr(df["Critic_Score"], df["Global_Sales"])
print(f"Pearson  r(Critic_Score, Global_Sales)       = {r_raw:.4f}  p = {p_raw:.2e}")
print(f"Pearson  r(Critic_Score, log10 Global_Sales) = {r_log:.4f}  p = {p_log:.2e}")
print(f"Spearman rho(Critic_Score, Global_Sales)     = {rho:.4f}  p = {p_rho:.2e}")
print("-> raw Pearson is damped by outliers (Wii Sports etc.); Spearman and log-Pearson agree")

cols = ["log_sales", "Critic_Score", "User_Score", "log_critic_count", "Year_of_Release"]
print("\nPearson correlation matrix:")
print(df[cols].corr().round(3).to_string())

fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
axes[0].scatter(df["Critic_Score"], df["Global_Sales"], s=6, alpha=0.3)
axes[0].set_xlabel("Critic score (0-100)")
axes[0].set_ylabel("Global sales, mln copies")
axes[0].set_title(f"Raw scale: Pearson r = {r_raw:.2f}")
axes[1].scatter(df["Critic_Score"], df["log_sales"], s=6, alpha=0.3)
axes[1].set_xlabel("Critic score (0-100)")
axes[1].set_ylabel("log10(global sales, mln)")
axes[1].set_title(f"Log scale: Pearson r = {r_log:.2f}, Spearman rho = {rho:.2f}")
save_fig(fig, "sr06_scatter")

header("2. Simple linear regression: log_sales = b0 + b1 * Critic_Score")
lr = stats.linregress(df["Critic_Score"], df["log_sales"])
print(f"b0 = {lr.intercept:.4f}, b1 = {lr.slope:.5f} (SE {lr.stderr:.5f}), p = {lr.pvalue:.2e}")
print(f"R^2 = {lr.rvalue ** 2:.4f}")
print(f"+10 critic points -> sales x {10 ** (10 * lr.slope):.3f}")
for s in [60, 75, 90]:
    print(f"  predicted median sales at score {s}: {10 ** (lr.intercept + lr.slope * s):.3f} mln")

xs = np.linspace(df["Critic_Score"].min(), df["Critic_Score"].max(), 100)
fig, ax = plt.subplots(figsize=(8, 4.5))
ax.scatter(df["Critic_Score"], df["log_sales"], s=6, alpha=0.25, label="games")
ax.plot(xs, lr.intercept + lr.slope * xs, color="#C44E52", lw=2,
        label=f"y = {lr.intercept:.2f} + {lr.slope:.4f}x,  R^2 = {lr.rvalue ** 2:.3f}")
ax.set_xlabel("Critic score (0-100)")
ax.set_ylabel("log10(global sales, mln)")
ax.set_title("Simple linear regression")
ax.legend()
save_fig(fig, "sr06_simple_regression")


# ------------------------------------------------------------------ multiple OLS
def ols(y, X, names):
    """OLS with standard errors, t, p, R^2, adjusted R^2 (numpy only)."""
    X = np.column_stack([np.ones(len(X)), X])
    n, k = X.shape
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ beta
    sse = resid @ resid
    sst = ((y - y.mean()) ** 2).sum()
    sigma2 = sse / (n - k)
    se = np.sqrt(np.diag(sigma2 * np.linalg.inv(X.T @ X)))
    t = beta / se
    p = 2 * stats.t.sf(np.abs(t), n - k)
    r2 = 1 - sse / sst
    adj = 1 - (1 - r2) * (n - 1) / (n - k)
    f = (r2 / (k - 1)) / ((1 - r2) / (n - k))
    table = pd.DataFrame({"coef": beta, "std_err": se, "t": t, "p_value": p},
                         index=["const"] + names)
    return table, r2, adj, f, X @ beta, resid


header("3. Multiple regression")
predictors = ["Critic_Score", "User_Score", "log_critic_count", "Year_of_Release"]
print("y = log10(Global_Sales); predictors:", predictors)
print("Why these: two quality signals (critics, players), media attention / hype\n"
      "(how many critics reviewed the game), and release year (market changes).\n"
      "Not used: regional sales (parts of y itself -> leakage), User_Count (counted\n"
      "after release, also a consequence of sales), Name/Developer (identifiers).")
vif_X = df[predictors]
for c in predictors:
    others = [o for o in predictors if o != c]
    _, r2c, *_ = ols(vif_X[c].to_numpy(), vif_X[others].to_numpy(), others)
    print(f"  VIF({c}) = {1 / (1 - r2c):.2f}")

y = df["log_sales"].to_numpy()
table, r2, adj, f, fitted, resid = ols(y, df[predictors].to_numpy(), predictors)
print()
print(table.round(5).to_string())
print(f"\nR^2 = {r2:.4f}, adjusted R^2 = {adj:.4f}, F = {f:.1f}")
print("\nInterpretation (coef on log10 scale -> multiplicative effect on sales):")
eff = {
    "Critic_Score": ("+10 critic points", 10),
    "User_Score": ("+1 user point", 1),
    "log_critic_count": ("x2 more critic reviews", np.log10(2)),
    "Year_of_Release": ("+1 year later", 1),
}
for c, (txt, step) in eff.items():
    mult = 10 ** (table.loc[c, "coef"] * step)
    print(f"  {txt:<24} -> sales x {mult:.3f} ({(mult - 1) * 100:+.1f}%), other things equal")

# standardised coefficients
zX = (df[predictors] - df[predictors].mean()) / df[predictors].std()
zy = (y - y.mean()) / y.std()
ztab, *_ = ols(zy, zX.to_numpy(), predictors)
print("\nstandardised betas (which predictor matters most):")
print(ztab["coef"].iloc[1:].round(3).to_string())

header("4. Residual diagnostics")
print(f"mean residual = {resid.mean():.2e}, sd = {resid.std():.4f}, skew = {stats.skew(resid):.3f}")
bins = pd.qcut(fitted, 5)
print("residual mean / sd by fitted-value quintile:")
print(pd.DataFrame({"r": resid, "b": bins}).groupby("b", observed=True)["r"]
      .agg(["mean", "std"]).round(3).to_string())

fig, axes = plt.subplots(1, 3, figsize=(14, 4))
axes[0].scatter(fitted, resid, s=5, alpha=0.3)
axes[0].axhline(0, color="#C44E52")
axes[0].set_xlabel("Fitted log10(sales)")
axes[0].set_ylabel("Residual")
axes[0].set_title("Residuals vs fitted")
axes[1].hist(resid, bins=50, color="#8172B2", edgecolor="white")
axes[1].set_xlabel("Residual")
axes[1].set_ylabel("Number of games")
axes[1].set_title("Residual distribution")
stats.probplot(resid, dist="norm", plot=axes[2])
axes[2].set_title("Normal Q-Q plot of residuals")
save_fig(fig, "sr06_residuals")
