"""SR 1. Python basics for data analysis.

Lists, dicts, sets, tuples, functions with keyword/default arguments,
comprehensions - on small "video game" examples. Everything is done
manually (no sum()/len()/numpy) to show what NumPy/pandas later vectorise.
"""

# ---------- 1. list: creation, indexing, slicing, mutability ----------
scores = [76, 82, 91, 58, 88, 70, 95]          # critic scores of 7 games
print("scores:", scores)
print("first:", scores[0], "| last:", scores[-1], "| slice [1:4]:", scores[1:4])
scores[3] = 60                                  # lists are mutable
print("after scores[3] = 60:", scores)

# ---------- 2. tuple: immutable record + unpacking ----------
game = ("Portal 2", "PC", 2011, 95)             # (name, platform, year, score)
name, platform, year, score = game              # tuple unpacking
print(f"\ntuple unpacked -> {name} / {platform} / {year} / {score}")
try:
    game[3] = 100                               # tuples are immutable
except TypeError as err:
    print("tuple is immutable:", err)

# ---------- 3. dict: key -> value ----------
sales = {"Wii Sports": 82.53, "GTA V": 21.04, "Minecraft": 14.24}
sales["Tetris"] = 30.26                         # add new key
print("\nsales dict:", sales)
print("GTA V sales:", sales["GTA V"], "| unknown key via get():", sales.get("Doom", 0.0))
for title, mln in sales.items():
    print(f"  {title:<12} {mln:6.2f} mln")

# ---------- 4. set: unique values ----------
platforms = ["PS4", "PC", "PS4", "XOne", "PC", "Switch"]
unique_platforms = set(platforms)
print("\nunique platforms:", sorted(unique_platforms))
print("intersection with {'PC','Wii'}:", unique_platforms & {"PC", "Wii"})


# ---------- 5. functions ----------
def manual_mean(values):
    """Arithmetic mean without sum() and len()."""
    total = 0.0
    count = 0
    for v in values:
        total += v
        count += 1
    if count == 0:
        raise ValueError("empty list")
    return total / count


def filter_by(values, threshold=75, keep_above=True):
    """Keyword arguments with default values."""
    if keep_above:
        return [v for v in values if v >= threshold]
    return [v for v in values if v < threshold]


def manual_variance(values, ddof=1):
    """Sample variance (ddof=1) or population variance (ddof=0), manually."""
    m = manual_mean(values)
    sq = 0.0
    n = 0
    for v in values:
        sq += (v - m) ** 2
        n += 1
    return sq / (n - ddof)


def count_by_key(records, key_index=1):
    """Frequency table from a list of tuples (what value_counts() does)."""
    freq = {}
    for rec in records:
        k = rec[key_index]
        freq[k] = freq.get(k, 0) + 1
    return freq


print("\nmanual_mean(scores) =", round(manual_mean(scores), 3))
print("filter_by(scores) =", filter_by(scores))
print("filter_by(scores, threshold=80, keep_above=False) =",
      filter_by(scores, threshold=80, keep_above=False))
print("manual_variance(scores) =", round(manual_variance(scores), 3))

games = [
    ("Portal 2", "PC", 2011, 95),
    ("Halo 3", "X360", 2007, 94),
    ("Mario Kart Wii", "Wii", 2008, 82),
    ("Skyrim", "PC", 2011, 94),
    ("Wii Fit", "Wii", 2007, 80),
]
print("count_by_key(games, 1) =", count_by_key(games, 1))

# ---------- 6. comprehensions ----------
squares = [s ** 2 for s in scores]
title_len = {g[0]: len(g[0]) for g in games}
pc_titles = [g[0] for g in games if g[1] == "PC"]
print("\nlist comprehension (squares):", squares)
print("dict comprehension (title length):", title_len)
print("filtered comprehension (PC games):", pc_titles)

# ---------- 7. check against the built-ins ----------
assert abs(manual_mean(scores) - sum(scores) / len(scores)) < 1e-9
print("\nself-check passed: manual_mean == sum/len")
