"""SR 3. Descriptive statistics and visualisation of the own dataset."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from common import load_clean, save_fig, header

df = load_clean()
num_cols = ["Global_Sales", "Critic_Score", "User_Score"]
units = {"Global_Sales": "mln copies", "Critic_Score": "points, 0-100",
         "User_Score": "points, 0-10"}


def describe_full(s: pd.Series) -> pd.Series:
    d = s.describe()
    q1, q3 = d["25%"], d["75%"]
    iqr = q3 - q1
    low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    out = ((s < low) | (s > high)).sum()
    extra = pd.Series({
        "median": s.median(),
        "mode": s.mode().iloc[0],
        "var": s.var(),
        "cv_%": s.std() / s.mean() * 100,
        "skew": s.skew(),
        "kurtosis": s.kurt(),
        "IQR": iqr,
        "outliers_IQR": out,
        "outliers_%": out / len(s) * 100,
    })
    return pd.concat([d, extra])


header("1. Numeric variables: full descriptive statistics")
stats = pd.DataFrame({c: describe_full(df[c]) for c in num_cols})
print(stats.round(3).to_string())

for c in num_cols:
    sk = df[c].skew()
    shape = "approximately symmetric" if abs(sk) < 0.5 else (
        "right-skewed (long right tail)" if sk > 0 else "left-skewed (long left tail)")
    print(f"{c}: skew={sk:.2f} -> {shape}")

# histograms
fig, axes = plt.subplots(1, 3, figsize=(13, 4))
for ax, c in zip(axes, num_cols):
    ax.hist(df[c], bins=40, color="#4C72B0", edgecolor="white")
    ax.axvline(df[c].mean(), color="#C44E52", lw=1.5, label=f"mean {df[c].mean():.2f}")
    ax.axvline(df[c].median(), color="#55A868", lw=1.5, ls="--",
               label=f"median {df[c].median():.2f}")
    ax.set_xlabel(f"{c} ({units[c]})")
    ax.set_ylabel("Number of games")
    ax.legend(fontsize=8)
fig.suptitle("Distribution of key numeric variables")
save_fig(fig, "sr03_hist_numeric")

# log-scale sales histogram + boxplot
log_sales = np.log10(df["Global_Sales"])
print(f"\nlog10(Global_Sales): skew={log_sales.skew():.2f}  (was {df['Global_Sales'].skew():.2f})")
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
axes[0].hist(log_sales, bins=40, color="#8172B2", edgecolor="white")
axes[0].set_xlabel("log10(Global sales, mln copies)")
axes[0].set_ylabel("Number of games")
axes[0].set_title("Sales on log scale: close to symmetric")
axes[1].boxplot([df["Critic_Score"], df["User_Score"] * 10], tick_labels=["Critic score", "User score x10"])
axes[1].set_ylabel("Score (0-100 scale)")
axes[1].set_title("Boxplots of scores (points beyond whiskers = outliers)")
save_fig(fig, "sr03_log_sales_box")

header("2. Categorical variables: frequency tables")
for c in ["Genre", "Rating"]:
    ft = df[c].value_counts().to_frame("count")
    ft["share_%"] = (ft["count"] / len(df) * 100).round(1)
    ft["cum_%"] = ft["share_%"].cumsum().round(1)
    print(f"\n{c}:\n{ft.to_string()}")

fig, axes = plt.subplots(1, 2, figsize=(13, 4.5), gridspec_kw={"width_ratios": [2.2, 1]})
g = df["Genre"].value_counts()
axes[0].bar(g.index.astype(str), g.values, color="#4C72B0")
axes[0].set_ylabel("Number of games")
axes[0].set_xlabel("Genre")
axes[0].set_ylim(0, None)
axes[0].tick_params(axis="x", rotation=45)
r = df["Rating"].value_counts().reindex(["E", "E10+", "T", "M"])
axes[1].bar(r.index.astype(str), r.values, color="#DD8452")
axes[1].set_ylabel("Number of games")
axes[1].set_xlabel("ESRB rating")
axes[1].set_ylim(0, None)
fig.suptitle("Frequency of categorical variables")
save_fig(fig, "sr03_bar_categorical")

header("3. groupby + agg: sales and scores by genre")
by_genre = (df.groupby("Genre", observed=True)
              .agg(games=("Name", "count"),
                   mean_sales=("Global_Sales", "mean"),
                   median_sales=("Global_Sales", "median"),
                   total_sales=("Global_Sales", "sum"),
                   mean_critic=("Critic_Score", "mean"),
                   mean_user=("User_Score", "mean"))
              .sort_values("median_sales", ascending=False))
print(by_genre.round(3).to_string())

fig, ax = plt.subplots(figsize=(9, 4.5))
ax.bar(by_genre.index.astype(str), by_genre["median_sales"], color="#55A868")
ax.set_ylabel("Median global sales, mln copies")
ax.set_xlabel("Genre")
ax.set_ylim(0, None)
ax.tick_params(axis="x", rotation=45)
ax.set_title("Median sales of one game by genre (median: robust to hits)")
save_fig(fig, "sr03_genre_median_sales")

header("4. Pivot table and crosstab")
pivot = pd.pivot_table(df, index="Genre", columns="Platform_Family",
                       values="Global_Sales", aggfunc="median", observed=True).round(2)
print("Median sales (mln) by Genre x Platform family:")
print(pivot.to_string())

ct = pd.crosstab(df["Genre"], df["Rating"], normalize="index").mul(100).round(1)
ct = ct[["E", "E10+", "T", "M"]]
print("\nCrosstab Genre x Rating (row %):")
print(ct.to_string())

region = pd.read_csv("data/region_sales_long.csv")
reg = region.pivot_table(index="Genre", columns="Region", values="Sales_mln", aggfunc="sum")
reg_share = reg.div(reg.sum(axis=0), axis=1).mul(100).round(1)
print("\nShare of genre in each region's total sales, % (from long table):")
print(reg_share[["NorthAmerica", "Europe", "Japan", "Other"]].to_string())

fig, ax = plt.subplots(figsize=(9, 6))
im = ax.imshow(pivot.values, cmap="Blues", aspect="auto")
ax.set_xticks(range(pivot.shape[1]), pivot.columns.astype(str))
ax.set_yticks(range(pivot.shape[0]), pivot.index.astype(str))
for i in range(pivot.shape[0]):
    for j in range(pivot.shape[1]):
        v = pivot.values[i, j]
        if not np.isnan(v):
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=8,
                    color="white" if v > 0.7 else "black")
ax.grid(False)
fig.colorbar(im, ax=ax, label="Median sales, mln copies")
ax.set_title("Median sales: genre x platform family")
save_fig(fig, "sr03_pivot_heatmap")
