"""SR 10. Machine learning: train/test split, overfitting, quality metrics.

Task: classification - will a game become a hit (>= 1 mln copies sold)?
Model: logistic regression (simple, few parameters).
Contrast: a decision tree without depth limit (very flexible -> overfits),
and the same tree with max_depth=4 (regularised).
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix, classification_report

from common import load_clean, save_fig, header, SEED

df = load_clean()
df["hit"] = (df["Global_Sales"] >= 1.0).astype(int)
df["log_critic_count"] = np.log10(df["Critic_Count"])

# User_Count is NOT used: it is accumulated after release and mostly reflects sales
# themselves (target leakage), same reasoning as in SR 6
num = ["Critic_Score", "User_Score", "log_critic_count", "Year_of_Release"]
X = pd.get_dummies(df[num + ["Genre", "Platform_Family", "Rating"]],
                   columns=["Genre", "Platform_Family", "Rating"], drop_first=True, dtype=float)
y = df["hit"]

header("1. Data and split")
print(f"objects: {len(X)}, features: {X.shape[1]}, share of hits: {y.mean():.3f}")
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, random_state=SEED, stratify=y)
print(f"train: {len(X_tr)}  test: {len(X_te)}  (75/25, stratified by class)")
print(f"baseline 'always not a hit': test accuracy = {1 - y_te.mean():.3f}, F1 = 0.000"
      "  -> accuracy alone is misleading, F1 is the main metric")

models = {
    "LogisticRegression": make_pipeline(StandardScaler(),
                                        LogisticRegression(max_iter=1000, class_weight="balanced")),
    "DecisionTree (no limit)": DecisionTreeClassifier(random_state=SEED),
    "DecisionTree (max_depth=4)": DecisionTreeClassifier(max_depth=4, class_weight="balanced",
                                                         random_state=SEED),
}

header("2. Train vs test metrics")
rows = []
for name, model in models.items():
    model.fit(X_tr, y_tr)
    p_tr, p_te = model.predict(X_tr), model.predict(X_te)
    rows.append({
        "model": name,
        "acc_train": accuracy_score(y_tr, p_tr), "acc_test": accuracy_score(y_te, p_te),
        "f1_train": f1_score(y_tr, p_tr), "f1_test": f1_score(y_te, p_te),
    })
res = pd.DataFrame(rows).set_index("model")
res["f1_gap"] = res["f1_train"] - res["f1_test"]
print(res.round(3).to_string())

header("3. Logistic regression in detail (test set)")
logit = models["LogisticRegression"]
pred = logit.predict(X_te)
print("confusion matrix [rows: true 0/1, cols: predicted 0/1]:")
print(confusion_matrix(y_te, pred))
print(classification_report(y_te, pred, target_names=["not hit", "hit"], digits=3))
coef = pd.Series(logit[-1].coef_[0], index=X.columns).sort_values()
print("largest standardised coefficients:")
print(pd.concat([coef.head(4), coef.tail(4)]).round(3).to_string())

header("4. Overfitting curve: tree depth vs F1")
depths = list(range(1, 21))
f_tr, f_te = [], []
for d in depths:
    t = DecisionTreeClassifier(max_depth=d, class_weight="balanced", random_state=SEED).fit(X_tr, y_tr)
    f_tr.append(f1_score(y_tr, t.predict(X_tr)))
    f_te.append(f1_score(y_te, t.predict(X_te)))
best = depths[int(np.argmax(f_te))]
print("depth: " + " ".join(f"{d:>5}" for d in depths))
print("train: " + " ".join(f"{v:5.2f}" for v in f_tr))
print("test:  " + " ".join(f"{v:5.2f}" for v in f_te))
print(f"best test F1 at depth = {best} ({max(f_te):.3f})")

fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))
x = np.arange(len(res))
axes[0].bar(x - 0.2, res["f1_train"], 0.4, label="train", color="#4C72B0")
axes[0].bar(x + 0.2, res["f1_test"], 0.4, label="test", color="#DD8452")
axes[0].set_xticks(x, ["Logistic\nregression", "Tree\n(no limit)", "Tree\n(depth 4)"])
axes[0].set_ylabel("F1 score (class 'hit')")
axes[0].set_ylim(0, 1.05)
axes[0].set_title("Train vs test F1")
axes[0].legend()
axes[1].plot(depths, f_tr, marker="o", label="train")
axes[1].plot(depths, f_te, marker="o", label="test")
axes[1].axvline(best, color="gray", ls="--", label=f"best test depth = {best}")
axes[1].set_xlabel("max_depth of the decision tree")
axes[1].set_ylabel("F1 score")
axes[1].set_ylim(0, 1.05)
axes[1].set_title("Overfitting: complexity vs quality")
axes[1].legend()
save_fig(fig, "sr10_overfitting")
