"""SR 9. Monte Carlo risk assessment and sensitivity analysis.

Model: indie game profit from SR 7.  Uncertain inputs get distributions;
the SHAPE of the sales distribution (lognormal, sigma of ln-sales) is taken
from the own dataset (SR 2/3), the scale (median copies) is an assumption
for a small indie title.
"""
import numpy as np
import matplotlib.pyplot as plt

from common import load_clean, save_fig, header, SEED

N = 100_000
rng = np.random.default_rng(SEED)
df = load_clean()

header("1. Input distributions")
sigma_ln = np.log(df["Global_Sales"]).std()
print(f"sigma of ln(Global_Sales) in the dataset = {sigma_ln:.3f} -> used as lognormal sigma")
MEDIAN_UNITS = 30_000

FIXED = dict(store_fee=0.30, refund_rate=0.05, tax_rate=0.05, team=4, salary=2_000.0,
             tools=6_000.0, support=10_000.0)


def sample_inputs(n, rng, units_sigma=sigma_ln, price_rng=(12, 18), months_sd=3.0,
                  mkt_rng=(15_000, 35_000)):
    return {
        "units": rng.lognormal(np.log(MEDIAN_UNITS), units_sigma, n),
        "price": rng.uniform(*price_rng, n),
        "months": np.clip(rng.normal(18, months_sd, n), 10, None),
        "marketing": rng.uniform(*mkt_rng, n),
    }


def profit(units, price, months, marketing):
    f = FIXED
    net = price * units * (1 - f["store_fee"] - f["refund_rate"]) * (1 - f["tax_rate"])
    costs = f["team"] * months * f["salary"] + f["tools"] + marketing + f["support"]
    return net - costs


print("units     ~ LogNormal(median 30 000, sigma from dataset)")
print("price     ~ Uniform(12, 18) USD")
print("months    ~ Normal(18, 3), cut at 10 (development time)")
print("marketing ~ Uniform(15 000, 35 000) USD")
print(f"scenarios: N = {N:,}, seed = {SEED}")

header("2. Risk assessment")
inp = sample_inputs(N, rng)
pi = profit(**inp)
q = np.percentile(pi, [5, 25, 50, 75, 95])
print(f"mean profit           = {pi.mean():>14,.0f} USD")
print(f"median profit         = {np.median(pi):>14,.0f} USD")
print(f"std                   = {pi.std():>14,.0f} USD")
print(f"P(loss) = P(profit<0) = {(pi < 0).mean():.4f}")
print(f"P(loss > 100k USD)    = {(pi < -100_000).mean():.4f}")
print(f"5% VaR (5th pct)      = {q[0]:>14,.0f} USD")
print("percentiles 5/25/50/75/95:", ", ".join(f"{v:,.0f}" for v in q))
print("deterministic SR7 base case = 92,875 USD ~ MC median; MC mean is ~6x larger\n"
      "because the lognormal sales tail is long: rare hits pull the mean up,\n"
      "while losses are bounded by total costs")
se = pi.std() / np.sqrt(N)
print(f"MC standard error of the mean = {se:,.0f} USD")

fig, ax = plt.subplots(figsize=(9, 4.8))
shown = pi[pi <= 1_000_000] / 1000
ax.hist(shown, bins=120, color="#4C72B0", edgecolor="none")
ax.text(0.98, 0.6, f"not shown: profit > 1 000k\nP = {(pi > 1_000_000).mean():.1%} of scenarios",
        transform=ax.transAxes, ha="right", fontsize=9)
ax.axvline(0, color="#C44E52", lw=2, label=f"Loss zone: P = {(pi < 0).mean():.1%}")
ax.axvline(np.median(pi) / 1000, color="black", ls="--", label=f"Median = {np.median(pi) / 1000:,.0f}k")
ax.axvline(q[0] / 1000, color="orange", ls=":", label=f"5th percentile = {q[0] / 1000:,.0f}k")
ax.set_xlabel("Profit, thousand USD")
ax.set_ylabel("Number of scenarios")
ax.set_title(f"Monte Carlo: distribution of profit, N = {N:,}")
ax.legend()
save_fig(fig, "sr09_profit_distribution")

header("3. Sensitivity analysis (one parameter varies, the rest fixed at central values)")
central = {"units": np.full(N, MEDIAN_UNITS), "price": np.full(N, 15.0),
           "months": np.full(N, 18.0), "marketing": np.full(N, 25_000.0)}
full = sample_inputs(N, np.random.default_rng(SEED + 1))
rows = []
for name in central:
    args = {k: v.copy() for k, v in central.items()}
    args[name] = full[name]
    p = profit(**args)
    p5, p95 = np.percentile(p, [5, 95])
    rows.append((name, p.std(), p5, p95, (p < 0).mean()))
rows.sort(key=lambda r: r[1], reverse=True)
print(f"{'parameter':<10} {'std of profit':>14} {'5th pct':>12} {'95th pct':>12} {'P(loss)':>8}")
for name, s, p5, p95, pl in rows:
    print(f"{name:<10} {s:>14,.0f} {p5:>12,.0f} {p95:>12,.0f} {pl:>8.3f}")

print("\nunits sigma sweep (how risk grows with sales uncertainty):")
sweep = []
for s in [0.25, 0.5, 0.75, 1.0, sigma_ln]:
    p = profit(**sample_inputs(N, np.random.default_rng(SEED), units_sigma=s))
    sweep.append((s, (p < 0).mean(), np.median(p)))
    print(f"  sigma = {s:.2f}: P(loss) = {(p < 0).mean():.3f}, median = {np.median(p):,.0f}")

fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))
names = [r[0] for r in rows][::-1]
lo = [r[2] / 1000 for r in rows][::-1]
hi = [r[3] / 1000 for r in rows][::-1]
base = profit(MEDIAN_UNITS, 15.0, 18.0, 25_000.0) / 1000
for i, (l, h) in enumerate(zip(lo, hi)):
    axes[0].barh(i, h - l, left=l, color="#55A868")
axes[0].set_yticks(range(len(names)), names)
axes[0].axvline(base, color="black", ls="--", label=f"Central case = {base:,.0f}k")
axes[0].set_xlabel("Profit 5th-95th percentile range, thousand USD")
axes[0].set_title("Tornado chart: which input drives the risk")
axes[0].legend()
axes[1].plot([s for s, *_ in sweep], [pl for _, pl, _ in sweep], marker="o")
axes[1].set_xlabel("sigma of ln(units)")
axes[1].set_ylabel("P(loss)")
axes[1].set_ylim(0, None)
axes[1].set_title("Loss probability vs sales uncertainty")
save_fig(fig, "sr09_sensitivity")
